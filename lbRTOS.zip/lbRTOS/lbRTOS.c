#include <FreeRTOS.h>
#include <task.h>
#include <SoR_Utils.h>



void vLEDon(){
	for(;;){
		LED_on();
		vTaskDelay(250/portTICK_RATE_MS);
	}
}

void vLightOn(){
	for(;;){
		PORT_ON(PORTA,0);
		vTaskDelay(250/portTICK_RATE_MS);
	}
}

void vServoOsc(){
	for(;;){
		//rprintf("Setting PWM to 1%% duty cycle\r\n");
		//PWM_timer2_Set_H6(1);
		//PWM_timer4_Set_H3(1);
		//delay_ms(1000); 

		//rprintf("Setting PWM to 50%% duty cycle\r\n");
		PWM_timer2_Set_H6(127);
		//PWM_timer4_Set_H3(127);
		//delay_ms(1000); 
		vTaskDelay(250/portTICK_RATE_MS);


	}
}


int main(void)
{
	configure_ports();
	//rprintf("Initializing timer2 for PWM\r\n");
	PWM_Init_timer2_H6(10);
	//PWM_Init_timer4_H3(10);

	//rprintf("Turning on both PWM channels\r\n");
	PWM_timer2_On_H6();
	//PWM_timer4_On_H3();
	LED_off();
	
	//while(!button_pressed());

	xTaskCreate(vLEDon, "LED ON", 100, NULL, 1, NULL);
	xTaskCreate(vLightOn, "Light on", 100, NULL, 1, NULL);
	xTaskCreate(vServoOsc, "servo go", 1000, NULL, 2, NULL);
	vTaskStartScheduler();
	for(;;);
	return 0;
}
